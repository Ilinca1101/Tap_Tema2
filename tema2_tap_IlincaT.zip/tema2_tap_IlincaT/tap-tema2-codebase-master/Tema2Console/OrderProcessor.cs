﻿using Newtonsoft.Json.Converters;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Tema2Console
{
    public class OrderProcessor: IOrderProcessor
    {
        public decimal ProcessOrder(Order order)
        {
            Console.WriteLine("Start processing...");

            decimal finalPrice = CalculateFinalPrice(order);

            Console.WriteLine("Rating completed.");
            return finalPrice;
        }

        private decimal CalculateFinalPrice(Order order)
        {
           

            //  prețul final va fi doar prețul comenzii.
            return order.Quantity * order.Price;

            
        }
    }
}
