﻿using Newtonsoft.Json;

namespace Tema2Console
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting Client...");
            IOrderProcessor orderProcessor = new OrderProcessor();

            var orderData = "{ \"type\": \"Room\", \"quantity\": 2, \"price\": 250, \"reservationDate\": \"10-05-2024\" }";

            var finalPrice = orderProcessor.ProcessOrder(JsonConvert.DeserializeObject<Order>(orderData));


            Console.WriteLine($"Final price for your order: {finalPrice} RON");


        }
    }
}
