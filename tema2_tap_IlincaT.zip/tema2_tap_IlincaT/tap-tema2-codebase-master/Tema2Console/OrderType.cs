﻿namespace Tema2Console
{
    public enum OrderType
    {
        Room,
        Product,
        Breakfast
    }
}
