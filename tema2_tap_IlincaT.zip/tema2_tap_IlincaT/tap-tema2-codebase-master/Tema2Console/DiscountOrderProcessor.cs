﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tema2Console
{
    public class DiscountOrderProcessor: IOrderProcessor
    {
        public decimal ProcessOrder(Order order)
        {
            Console.WriteLine("Start processing with discount...");

            decimal finalPrice = CalculateFinalPriceWithDiscount(order);

            Console.WriteLine("Rating with discount completed.");
            return finalPrice;
        }

        private decimal CalculateFinalPriceWithDiscount(Order order)
        {
          
                return order.Quantity * order.Price * 0.9m;
            
        }
    }
}
